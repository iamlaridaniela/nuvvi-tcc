<?php
session_start();
require_once 'db.php';

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];
    $senha2 = $_POST['senha2'];

    if ($nome === '' || $email === '' || $senha === '' || $senha2 === '') {
        $erro = "Preencha todos os campos.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = "E-mail inválido.";
    } elseif ($senha !== $senha2) {
        $erro = "As senhas não coincidem.";
    } elseif (strlen($senha) < 6) {
        $erro = "A senha deve ter pelo menos 6 caracteres.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $erro = "E-mail já cadastrado. Faça login.";
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $nome, $email, $hash);

            if ($stmt->execute()) {
                $sucesso = "Cadastro realizado com sucesso! Faça login.";
            } else {
                $erro = "Erro ao cadastrar. Tente novamente.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Criar Conta | NUVVI</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      height: 100vh;
      width: 100vw;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #f5f5f5;
    }

    .container {
      width: 100%;
      height: 100%;
      display: flex;
      background: #fff;
    }

    /* Lado esquerdo com imagem */
    .left {
      flex: 1;
      background: url('img/login.png') no-repeat center center;
      background-size: cover;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-start;
      color: #fff;
      padding: 80px;
      position: relative;
    }

    .left::before {
      content: "";
      position: absolute;
      inset: 0;
      background: rgba(45, 87, 44, 0.55);
      z-index: 0;
    }

    .left h1, .left p {
      position: relative;
      z-index: 1;
    }

    .left h1 {
      font-size: 3rem;
      font-weight: 600;
      margin-bottom: 15px;
    }

    .left p {
      font-size: 1.1rem;
      line-height: 1.6;
      opacity: 0.95;
    }

    /* Lado direito (formulário) */
    .right {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center; /* Centraliza horizontalmente */
      padding: 50px 100px; /* Ajuste para centralizar melhor na direita */
    }

    .right-content {
      width: 100%;
      max-width: 400px;
    }

    .right h2 {
      font-size: 2.2rem;
      font-weight: 600;
      color: #2d572c;
      margin-bottom: 30px;
      text-align: center;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 18px;
      width: 100%;
    }

    .input-group input {
      width: 100%;
      padding: 14px 18px;
      border-radius: 25px;
      border: 1px solid #ccc;
      outline: none;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .input-group input:focus {
      border-color: #2d572c;
      box-shadow: 0 0 4px rgba(45, 87, 44, 0.3);
    }

    button {
      background: linear-gradient(135deg, #2d572c, #3c783a);
      color: #fff;
      border: none;
      border-radius: 25px;
      padding: 14px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: 0.3s;
    }

    button:hover {
      background: linear-gradient(135deg, #244c25, #336b33);
    }

    .erro, .sucesso {
      border-radius: 6px;
      padding: 10px;
      margin-bottom: 10px;
      font-size: 0.9rem;
      text-align: center;
    }

    .erro {
      background-color: #ffdada;
      color: #a94442;
      border: 1px solid #e6a1a1;
    }

    .sucesso {
      background-color: #d4edda;
      color: #2d572c;
      border: 1px solid #a9d18e;
    }

    .login-link {
      margin-top: 15px;
      font-size: 0.95rem;
      text-align: center;
    }

    .login-link a {
      color: #2d572c;
      text-decoration: none;
      font-weight: 500;
    }

    .login-link a:hover {
      text-decoration: underline;
    }

    @media (max-width: 900px) {
      .container {
        flex-direction: column;
      }

      .left, .right {
        flex: none;
        width: 100%;
        height: 50%;
        align-items: center;
        text-align: center;
        padding: 50px;
      }

      form {
        align-items: center;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="left">
      <h1>Crie sua conta</h1>
      <p>Cadastre-se para aproveitar todas as vantagens da NUVVI.</p>
    </div>

    <div class="right">
      <div class="right-content">
        <h2>Criar conta</h2>
        <?php
          if ($erro) echo "<div class='erro'>$erro</div>";
          if ($sucesso) echo "<div class='sucesso'>$sucesso</div>";
        ?>
        <form method="POST">
          <div class="input-group">
            <input type="text" name="nome" placeholder="Nome completo" required>
          </div>
          <div class="input-group">
            <input type="email" name="email" placeholder="E-mail" required>
          </div>
          <div class="input-group">
            <input type="password" name="senha" placeholder="Senha" required>
          </div>
          <div class="input-group">
            <input type="password" name="senha2" placeholder="Confirmar senha" required>
          </div>
          <button type="submit">Cadastrar</button>
        </form>
        <p class="login-link">Já tem conta? <a href="login.php">Entrar</a></p>
      </div>
    </div>
  </div>
</body>
</html>

