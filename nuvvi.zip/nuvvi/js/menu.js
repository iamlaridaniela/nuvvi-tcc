document.addEventListener('DOMContentLoaded', () => {
  // ======================================================
  // MENU HAMBÚRGUER E SIDEBAR
  // ======================================================
  const btnMenu = document.getElementById('btn-menu');
  const closeMenu = document.getElementById('close-menu');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');

  function toggleMenu(open) {
    sidebar.classList.toggle('open', open);
    overlay.classList.toggle('active', open);
    btnMenu.classList.toggle('active', open);
    btnMenu.setAttribute('aria-expanded', String(open));
    sidebar.setAttribute('aria-hidden', String(!open));
    document.body.style.overflow = open ? 'hidden' : '';
  }

  if (btnMenu) {
    btnMenu.addEventListener('click', () => toggleMenu(!sidebar.classList.contains('open')));
  }

  if (closeMenu) {
    closeMenu.addEventListener('click', () => toggleMenu(false));
  }

  if (overlay) {
    overlay.addEventListener('click', () => toggleMenu(false));
  }

  // Fechar com tecla ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && sidebar.classList.contains('open')) {
      toggleMenu(false);
    }
  });

  // Fechar menu ao clicar em um link
  const menuLinks = document.querySelectorAll('.menu a');
  menuLinks.forEach(link => {
    link.addEventListener('click', () => {
      setTimeout(() => toggleMenu(false), 200);
    });
  });

  // ======================================================
  // GERENCIAMENTO DE USUÁRIO
  // ======================================================
  const userAvatar = sidebar.querySelector('.avatar');
  const userName = sidebar.querySelector('.username');
  const userStatus = sidebar.querySelector('.user-status');
  const logoutLink = sidebar.querySelector('a[href="logout.php"]');
  const loginLinks = sidebar.querySelectorAll('a[href="login.php"], a[href="registrar.php"]');

  const body = document.body;
  const name = body.dataset.username?.trim();
  const avatar = body.dataset.avatar?.trim();

  const defaultAvatar = 'img/avatar.webp';

  // Se o usuário estiver logado
  if (name && name.length > 0 && name !== 'Visitante') {
    if (userAvatar) {
      userAvatar.src = avatar && avatar.length > 0 ? avatar : defaultAvatar;
    }
    if (userName) {
      userName.textContent = name;
    }
    if (userStatus) {
      userStatus.style.display = 'inline-block';
    }
    if (logoutLink) {
      logoutLink.style.display = 'flex';
    }
    loginLinks.forEach(link => {
      if (link.parentElement) {
        link.parentElement.style.display = 'none';
      }
    });
  } else {
    // Visitante (sem login)
    if (userAvatar) {
      userAvatar.src = defaultAvatar + '?v=' + new Date().getTime();
    }
    if (userName) {
      userName.textContent = 'Visitante';
    }
    if (userStatus) {
      userStatus.style.display = 'none';
    }
    if (logoutLink && logoutLink.parentElement) {
      logoutLink.parentElement.style.display = 'none';
    }
    loginLinks.forEach(link => {
      if (link.parentElement) {
        link.parentElement.style.display = 'block';
      }
    });
  }

  // ======================================================
  // LOGOUT
  // ======================================================
  if (logoutLink) {
    logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      
      fetch('logout.php')
        .then(response => {
          if (response.ok) {
            // Limpa dados visuais
            if (userAvatar) {
              userAvatar.src = defaultAvatar + '?v=' + new Date().getTime();
            }
            if (userName) {
              userName.textContent = 'Visitante';
            }
            if (userStatus) {
              userStatus.style.display = 'none';
            }
            if (logoutLink && logoutLink.parentElement) {
              logoutLink.parentElement.style.display = 'none';
            }
            loginLinks.forEach(link => {
              if (link.parentElement) {
                link.parentElement.style.display = 'block';
              }
            });

            // Redireciona para a página principal após um delay
            setTimeout(() => {
              window.location.href = 'index.php';
            }, 300);
          } else {
            window.location.href = 'index.php';
          }
        })
        .catch(() => {
          window.location.href = 'index.php';
        });
    });
  }
});