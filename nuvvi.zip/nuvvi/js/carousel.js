// =============================
//  CARROSSEL NUVVI
// =============================

const track = document.querySelector('.carousel-track');
const slides = Array.from(document.querySelectorAll('.slide'));

const btnPrev = document.querySelector('.prev');
const btnNext = document.querySelector('.next');

let currentIndex = 0;
let totalSlides = slides.length;

// Função para atualizar a posição
function updateCarousel() {
    const offset = currentIndex * -100;
    track.style.transform = `translateX(${offset}%)`;
}

// Botão: Próximo
btnNext.addEventListener('click', () => {
    currentIndex++;
    if (currentIndex >= totalSlides) currentIndex = 0;
    updateCarousel();
});

// Botão: Anterior
btnPrev.addEventListener('click', () => {
    currentIndex--;
    if (currentIndex < 0) currentIndex = totalSlides - 1;
    updateCarousel();
});

// Troca automática a cada 6s
setInterval(() => {
    currentIndex++;
    if (currentIndex >= totalSlides) currentIndex = 0;
    updateCarousel();
}, 6000);
