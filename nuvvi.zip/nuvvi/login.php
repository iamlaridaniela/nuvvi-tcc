<?php
session_start();
require_once 'db.php';

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($senha, $user['senha'])) {
            // Armazena as informações do usuário na sessão
            $_SESSION['user'] = [
                'id' => $user['id'],
                'name' => $user['nome'],
                'email' => $user['email'],
                'avatar' => !empty($user['avatar']) ? $user['avatar'] : 'img/avatar.webp'
            ];
            
            header("Location: index.php");
            exit;
        } else {
            $erro = "Senha incorreta.";
        }
    } else {
        $erro = "Usuário não encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Entrar | NUVVI</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      height: 100vh;
      width: 100vw;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #f5f5f5;
    }

    .container {
      width: 100%;
      height: 100%;
      display: flex;
      background: #fff;
    }

    /* Lado esquerdo com imagem */
    .left {
      flex: 1;
      background: url('img/login.png') no-repeat center center;
      background-size: cover;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-start;
      color: #fff;
      padding: 80px;
      position: relative;
    }

    .left::before {
      content: "";
      position: absolute;
      inset: 0;
      background: rgba(45, 87, 44, 0.55);
      z-index: 0;
    }

    .left h1, .left p {
      position: relative;
      z-index: 1;
    }

    .left h1 {
      font-size: 3rem;
      font-weight: 600;
      margin-bottom: 15px;
    }

    .left p {
      font-size: 1.1rem;
      line-height: 1.6;
      opacity: 0.95;
    }

    /* Lado direito (formulário) */
    .right {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 80px 60px;
      position: relative;
    }

    .form-box {
      width: 100%;
      max-width: 420px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .right h2 {
      font-size: 2.2rem;
      font-weight: 600;
      color: #2d572c;
      margin-bottom: 30px;
      text-align: center;
    }

    form {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .input-group input {
      width: 100%;
      padding: 14px 18px;
      border-radius: 25px;
      border: 1px solid #ccc;
      outline: none;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .input-group input:focus {
      border-color: #2d572c;
      box-shadow: 0 0 4px rgba(45, 87, 44, 0.3);
    }

    .options {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.9rem;
      color: #333;
    }

    .options a {
      color: #2d572c;
      text-decoration: none;
      font-weight: 500;
    }

    .options a:hover {
      text-decoration: underline;
    }

    button {
      background: linear-gradient(135deg, #2d572c, #3c783a);
      color: #fff;
      border: none;
      border-radius: 25px;
      padding: 14px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: 0.3s;
    }

    button:hover {
      background: linear-gradient(135deg, #244c25, #336b33);
    }

    .erro {
      background-color: #ffdada;
      color: #a94442;
      border: 1px solid #e6a1a1;
      border-radius: 6px;
      padding: 10px;
      margin-bottom: 10px;
      font-size: 0.9rem;
      width: 100%;
    }

    .signup-link {
      margin-top: 15px;
      font-size: 0.95rem;
      text-align: center;
    }

    .signup-link a {
      color: #2d572c;
      text-decoration: none;
      font-weight: 500;
    }

    .signup-link a:hover {
      text-decoration: underline;
    }

    @media (max-width: 900px) {
      .container {
        flex-direction: column;
      }

      .left, .right {
        flex: none;
        width: 100%;
        height: 50%;
        align-items: center;
        text-align: center;
        padding: 50px;
      }

      form {
        align-items: center;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="left">
      <h1>Bem-vindo de volta!</h1>
      <p>Faça login para acessar sua conta e continuar sua jornada natural com a NUVVI.</p>
    </div>

    <div class="right">
      <div class="form-box">
        <h2>Entrar</h2>
        <?php if (!empty($erro)) echo "<p class='erro'>$erro</p>"; ?>
        <form method="POST">
          <div class="input-group">
            <input type="email" name="email" placeholder="Digite seu e-mail" required>
          </div>
          <div class="input-group">
            <input type="password" name="senha" placeholder="Digite sua senha" required>
          </div>
          <div class="options">
            <label><input type="checkbox" name="lembrar"> Lembrar-me</label>
            <a href="#">Esqueceu a senha?</a>
          </div>
          <button type="submit">Entrar</button>
        </form>
        <p class="signup-link">Novo por aqui? <a href="registrar.php">Crie uma conta</a></p>
      </div>
    </div>
  </div>
</body>
</html>