<?php
session_start();
require_once 'db.php';

// Usuário logado
$isLogged = !empty($_SESSION['user']);
$userAvatar = $isLogged && !empty($_SESSION['user']['avatar']) 
    ? "img/" . basename($_SESSION['user']['avatar']) 
    : 'img/avatar.webp';
$userName = $isLogged && !empty($_SESSION['user']['name']) 
    ? $_SESSION['user']['name'] 
    : 'Visitante';

// Inicializa carrinho
if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

// Adicionar item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['produto_id'])) {
    $produto_id = intval($_POST['produto_id']);
    
    $stmt = $conn->prepare("INSERT id, nome, preco, imagem FROM produtos WHERE id = ?");
    $stmt->bind_param("i", $produto_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($produto = $result->fetch_assoc()) {
        if (isset($_SESSION['carrinho'][$produto_id])) {
            $_SESSION['carrinho'][$produto_id]['quantidade']++;
        } else {
            $_SESSION['carrinho'][$produto_id] = [
                'nome' => $produto['nome'],
                'preco' => floatval($produto['preco']),
                'imagem' => $produto['imagem'],
                'quantidade' => 1
            ];
        }
    }

    header("Location: carrinho.php");
    exit;
}

// Remover item
if (isset($_GET['remover'])) {
    $remover_id = intval($_GET['remover']);
    unset($_SESSION['carrinho'][$remover_id]);
    header("Location: carrinho.php");
    exit;
}

// Alterar quantidade
if (isset($_GET['acao'], $_GET['id'])) {
    $id = intval($_GET['id']);

    if (isset($_SESSION['carrinho'][$id])) {
        if ($_GET['acao'] === 'mais') {
            $_SESSION['carrinho'][$id]['quantidade']++;
        } elseif ($_GET['acao'] === 'menos') {
            $_SESSION['carrinho'][$id]['quantidade']--;
            if ($_SESSION['carrinho'][$id]['quantidade'] <= 0) {
                unset($_SESSION['carrinho'][$id]);
            }
        }
    }

    header("Location: carrinho.php");
    exit;
}

// Calcular total
$total = 0;
foreach ($_SESSION['carrinho'] as $item) {
    $total += floatval($item['preco']) * intval($item['quantidade']);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Carrinho | NUVVI</title>

<link rel="icon" href="img/icon.png" type="image/png" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

    <style>
    /* ========================================================== 
       FONT-FACE
    ========================================================== */
    @font-face {
        font-family: 'Playfair Display SC';
        src: url('./font/PlayfairDisplaySC-Regular.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
    }

    /* ==========================================================
       RESET E BASE
    ========================================================== */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: "Poppins", sans-serif;
        background-color: #f7f7f7;
        color: #333;
        overflow-x: hidden;
    }

    /* ==========================================================
       HEADER SUPERIOR
    ========================================================== */
    .site-header {
        background: #2d572c;
        color: white;
        padding: 1rem;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    /* ==========================================================
       MENU HAMBÚRGUER
    ========================================================== */
    .menu-icon {
        width: 45px;
        height: 45px;
        background: transparent;
        border: none;
        cursor: pointer;
        padding: 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 6px;
        margin-right: 1rem;
        transition: all 0.3s ease;
        position: relative;
    }

    .menu-icon span {
        display: block;
        width: 28px;
        height: 3px;
        background: white;
        border-radius: 3px;
        transition: all 0.3s ease;
        transform-origin: center;
    }

    .menu-icon.active span:nth-child(1) {
        transform: translateY(9px) rotate(45deg);
    }

    .menu-icon.active span:nth-child(2) {
        opacity: 0;
        transform: translateX(-20px);
    }

    .menu-icon.active span:nth-child(3) {
        transform: translateY(-9px) rotate(-45deg);
    }

    .top-bar {
        flex: 1;
        display: flex;
        justify-content: center;
    }

    .logo a {
        color: #fff;
        font-family: 'Playfair Display SC';
        text-decoration: none !important;
        letter-spacing: 3px;
        font-weight: 700;
        font-size: 1.3rem;
    }

    /* ==========================================================
       SIDEBAR
    ========================================================== */
    .sidebar {
        position: fixed;
        left: -250px;
        top: 0;
        height: 100vh;
        width: 250px;
        background: #fff;
        border-right: 1px solid #ccc;
        transition: left 0.4s ease;
        overflow-x: hidden;
        overflow-y: auto;
        z-index: 1001;
        box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.open {
        left: 0;
    }

    .sidebar-header {
        text-align: center;
        padding: 1.5rem 1rem;
        border-bottom: 1px solid #e0e0e0;
        background: #2d572c;
        position: relative;
    }

    .avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid white;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        transition: transform 0.3s ease;
        margin-bottom: 0.8rem;
    }

    .avatar:hover {
        transform: scale(1.05);
    }

    .username {
        font-weight: 600;
        font-size: 1.1rem;
        color: white;
        margin: 0.5rem 0 0.3rem 0;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    }

    .user-status {
        display: inline-block;
        font-size: 0.8rem;
        color: white;
        background: rgba(255, 255, 255, 0.2);
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-weight: 500;
        backdrop-filter: blur(10px);
    }

    .user-status.guest {
        background: rgba(255, 255, 255, 0.15);
    }

    .close-menu {
        position: absolute;
        top: 1rem;
        right: 1rem;
        width: 40px;
        height: 40px;
        background: rgba(255, 255, 255, 0.3);
        border: 2px solid rgba(255, 255, 255, 0.5);
        border-radius: 50%;
        color: white;
        font-size: 1.5rem;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        line-height: 1;
    }

    .close-menu:hover {
        background: rgba(255, 255, 255, 0.5);
        transform: rotate(90deg);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    }

    /* ==========================================================
       MENU LATERAL
    ========================================================== */
    .menu {
        margin-top: 1rem;
        padding: 0 0.8rem;
        max-height: calc(100vh - 250px);
        overflow-y: auto;
    }

    .menu::-webkit-scrollbar {
        width: 6px;
    }

    .menu::-webkit-scrollbar-thumb {
        background: #2d572c;
    }

    .menu ul {
        list-style: none;
    }

    .menu ul li a {
        text-decoration: none;
        color: #333;
        font-weight: 600;
        font-size: 0.95rem;
        padding: 12px 14px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 12px;
        transition: 0.3s;
    }

    .menu ul li a:hover,
    .menu ul li a.active {
        background-color: #2d572c;
        color: #fff;
        transform: translateX(5px);
    }

    .menu-divider {
        height: 1px;
        background: #e0e0e0;
        margin: 0.8rem 0;
    }

    .menu-section {
        margin-top: 1.5rem;
    }

    .menu-section-title {
        font-size: 0.85rem;
        font-weight: 700;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 1px;
        padding: 0 14px;
        margin-bottom: 0.5rem;
    }

    .overlay {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 999;
    }

    .overlay.active {
        opacity: 1;
        visibility: visible;
    }

    /* ==========================================================
       BARRA DE PESQUISA
    ========================================================== */
    .search-bar {
        width: 100%;
        display: flex;
        justify-content: center;
        background: #f1f1ee;
        padding: 18px 0;
        position: sticky;
        top: 60px;
        z-index: 999;
        transition: all 0.3s ease;
    }

    .search-bar form {
        width: 100%;
        max-width: 600px;
        display: flex;
        background: #ffffff;
        border-radius: 35px;
        padding: 6px 14px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.07);
        border: 1px solid #e5e5e2;
    }

    .search-bar input {
        flex: 1;
        border: none;
        outline: none;
        padding: 12px 18px;
        font-size: 15px;
        background: transparent;
        color: #333;
    }

    .search-bar button {
        background: #7da77c;
        border: none;
        color: white;
        width: 46px;
        height: 46px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: 0.2s ease;
    }

    .search-bar button:hover {
        filter: brightness(1.1);
    }

    /* ==========================================================
       CONTEÚDO PRINCIPAL - CARRINHO
    ========================================================== */
    .container {
        max-width: 1250px;
        margin: 2rem auto;
        padding: 2rem;
        background: white;
        border-radius: 18px;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.08);
    }

    .page-title {
        font-size: 32px;
        font-weight: 700;
        color: #2d572c;
        margin-bottom: 2rem;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .carrinho-lista {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
        gap: 25px;
        margin-bottom: 2rem;
    }

    .carrinho-item {
        background: #fafafa;
        border: 2px solid #eee;
        border-radius: 16px;
        padding: 20px;
        text-align: center;
        transition: 0.3s ease;
    }

    .carrinho-item:hover {
        border-color: #2d572c;
        box-shadow: 0 4px 12px rgba(45, 87, 44, 0.1);
    }

    .carrinho-item img {
        width: 160px;
        height: 160px;
        object-fit: cover;
        border-radius: 12px;
        margin-bottom: 15px;
    }

    .carrinho-item h3 {
        font-size: 1.1rem;
        color: #333;
        margin-bottom: 12px;
        font-weight: 600;
    }

    .qtd-controls {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 15px;
        margin: 15px 0;
        background: white;
        padding: 8px;
        border-radius: 25px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
    }

    .qtd-controls a {
        background: #2d572c;
        color: white;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 1.1rem;
        text-decoration: none;
        transition: 0.2s ease;
    }

    .qtd-controls a:hover {
        background: #3d6d3c;
        transform: scale(1.1);
    }

    .qtd-controls strong {
        font-size: 1.2rem;
        color: #2d572c;
        min-width: 30px;
    }

    .carrinho-item .preco {
        font-size: 1.3rem;
        font-weight: 700;
        color: #2d572c;
        margin: 12px 0;
    }

    .remover {
        display: inline-block;
        margin-top: 12px;
        background: #ff6b6b;
        color: white;
        padding: 8px 18px;
        border-radius: 20px;
        text-decoration: none;
        font-weight: 600;
        font-size: 0.9rem;
        transition: 0.2s ease;
    }

    .remover:hover {
        background: #e05a5a;
        transform: translateY(-2px);
    }

    .carrinho-resumo {
        background: #f9fdf9;
        padding: 25px;
        border-radius: 16px;
        border: 2px solid #2d572c;
        margin-top: 2rem;
    }

    .total {
        text-align: right;
        font-size: 1.8rem;
        font-weight: 700;
        color: #2d572c;
        margin-bottom: 1.5rem;
    }

    .finalizar {
        display: inline-block;
        background: #2d572c;
        color: white;
        padding: 14px 32px;
        border-radius: 30px;
        text-decoration: none;
        font-weight: 600;
        font-size: 1.1rem;
        transition: 0.3s ease;
        float: right;
    }

    .finalizar:hover {
        background: #3d6d3c;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(45, 87, 44, 0.3);
    }

    .carrinho-vazio {
        text-align: center;
        padding: 4rem 2rem;
        color: #666;
    }

    .carrinho-vazio i {
        font-size: 4rem;
        color: #ccc;
        margin-bottom: 1rem;
    }

    .carrinho-vazio p {
        font-size: 1.2rem;
        margin-bottom: 1.5rem;
    }

    .btn-continuar {
        display: inline-block;
        background: #2d572c;
        color: white;
        padding: 12px 28px;
        border-radius: 30px;
        text-decoration: none;
        font-weight: 600;
        transition: 0.3s ease;
    }

    .btn-continuar:hover {
        background: #3d6d3c;
        transform: translateY(-2px);
    }

    /* ==========================================================
       FOOTER
    ========================================================== */
    .site-footer {
        background: #2d572c;
        color: #ffffff;
        padding: 60px 20px 20px 20px;
        margin-top: 60px;
    }

    .footer-container {
        max-width: 1250px;
        margin: auto;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 40px;
    }

    .footer-col {
        flex: 1 1 250px;
    }

    .footer-title {
        font-family: 'Playfair Display SC';
        font-size: 28px;
        margin-bottom: 10px;
        letter-spacing: 2px;
    }

    .footer-desc {
        color: #d9e6d9;
        font-size: 15px;
        line-height: 1.5;
        margin-top: 8px;
    }

    .footer-col h4 {
        font-size: 18px;
        margin-bottom: 15px;
        font-weight: 600;
        color: #e9f5ea;
    }

    .footer-col ul {
        list-style: none;
    }

    .footer-col ul li {
        margin-bottom: 10px;
    }

    .footer-col ul li a {
        color: #d9e6d9;
        text-decoration: none;
        transition: 0.2s ease;
    }

    .footer-col ul li a:hover {
        color: #ffffff;
        padding-left: 4px;
    }

    .footer-copy {
        text-align: center;
        font-size: 14px;
        margin-top: 35px;
        color: #d3e4d3;
    }

    /* ==========================================================
       RESPONSIVIDADE
    ========================================================== */
    @media (max-width: 700px) {
        .footer-container {
            text-align: center;
        }

        .footer-col {
            flex: 1 1 100%;
        }

        .carrinho-lista {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 600px) {
        .search-bar form {
            max-width: 90%;
        }

        .page-title {
            font-size: 24px;
        }

        .container {
            padding: 1rem;
        }
    }
    </style>
</head>

<body>

    <!-- HEADER -->
<header class="site-header">
    <button class="menu-icon" id="btn-menu" aria-label="Abrir menu" aria-expanded="false">
        <span></span><span></span><span></span>
    </button>

    <div class="top-bar">
        <h1 class="logo"><a href="index.php">NUVVI</a></h1>
    </div>
</header>

<!-- BARRA DE PESQUISA FIXA -->
<div class="search-bar" id="search-bar">
    <form action="produtos.php" method="GET">
        <input type="text" name="search" placeholder="Buscar produtos..." required>
        <button type="submit">
            <i class="fas fa-search"></i>
        </button>
    </form>
</div>

<!-- MENU LATERAL -->
<nav class="sidebar" id="sidebar" aria-hidden="true">
    <div class="sidebar-header">
        <button class="close-menu" id="close-menu">✕</button>

        <img src="<?= htmlspecialchars($userAvatar); ?>" class="avatar" />
        <p class="username"><?= htmlspecialchars($userName); ?></p>

        <?php if ($isLogged): ?>
        <span class="user-status">Online</span>
        <?php else: ?>
        <span class="user-status guest">Visitante</span>
        <?php endif; ?>
    </div>

    <div class="menu">
        <ul>
            <li><a href="index.php"><i class="fas fa-home"></i>Início</a></li>
            <li><a href="produtos.php"><i class="fas fa-box-open"></i>Produtos</a></li>

            <?php if ($isLogged): ?>
            <li><a href="carrinho.php" class="active"><i class="fas fa-shopping-cart"></i>Carrinho</a></li>
            <li class="menu-divider"></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i>Sair</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<div class="overlay" id="overlay"></div>

<!-- CONTEÚDO PRINCIPAL -->
<main>
    <div class="container">
        <h2 class="page-title">
            <i class="fas fa-shopping-cart"></i> Seu Carrinho
        </h2>

        <?php if (empty($_SESSION['carrinho'])): ?>
        <div class="carrinho-vazio">
            <i class="fas fa-shopping-cart"></i>
            <p>Seu carrinho está vazio</p>
            <a href="produtos.php" class="btn-continuar">
                <i class="fas fa-arrow-left"></i> Continuar comprando
            </a>
        </div>
        <?php else: ?>
        <div class="carrinho-lista">
            <?php foreach ($_SESSION['carrinho'] as $id => $item): ?>
            <?php
                $imgPath = !empty($item['imagem']) ? "img/" . basename($item['imagem']) : "img/placeholder.png";
            ?>
            <div class="carrinho-item">
                <img src="<?= htmlspecialchars($imgPath) ?>" alt="<?= htmlspecialchars($item['nome']) ?>">
                <h3><?= htmlspecialchars($item['nome']) ?></h3>

                <div class="qtd-controls">
                    <a href="?acao=menos&id=<?= $id ?>" title="Diminuir">−</a>
                    <strong><?= $item['quantidade'] ?></strong>
                    <a href="?acao=mais&id=<?= $id ?>" title="Aumentar">+</a>
                </div>

                <p class="preco">R$ <?= number_format($item['preco'] * $item['quantidade'], 2, ',', '.') ?></p>

                <a class="remover" href="?remover=<?= $id ?>">
                    <i class="fas fa-trash"></i> Remover
                </a>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="carrinho-resumo">
            <div class="total">
                Total: R$ <?= number_format($total, 2, ',', '.') ?>
            </div>

            <a href="pagamento.php" class="finalizar">
                <i class="fas fa-credit-card"></i> Finalizar Compra
            </a>
            <div style="clear: both;"></div>
        </div>
        <?php endif; ?>
    </div>
</main>

<!-- FOOTER -->
<footer class="site-footer">
    <div class="footer-container">
        <div class="footer-col">
            <h3 class="footer-title">NUVVI</h3>
            <p class="footer-desc">Beleza natural, leve e consciente.</p>
        </div>

        <div class="footer-col">
            <h4>Links úteis</h4>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="produtos.php">Produtos</a></li>
                <li><a href="contato.php">Contato</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Contato</h4>
            <p>Email: atendimento@nuvvi.com.br</p>
            <p>WhatsApp: (11) 99999-9999</p>
        </div>
    </div>

    <div class="footer-copy">
        © 2025 NUVVI — Todos os direitos reservados.
    </div>
</footer>

<!-- JS MENU -->
<script>
(function() {
    const btnMenu = document.getElementById('btn-menu');
    const closeMenu = document.getElementById('close-menu');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    function toggleMenu(open) {
        sidebar.classList.toggle('open', open);
        overlay.classList.toggle('active', open);
        btnMenu.classList.toggle('active', open);
        document.body.style.overflow = open ? 'hidden' : '';
    }

    btnMenu.onclick = () => toggleMenu(true);
    closeMenu.onclick = () => toggleMenu(false);
    overlay.onclick = () => toggleMenu(false);
})();
</script>

</body>
</html>