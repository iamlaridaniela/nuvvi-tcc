<?php
session_start();
header('Content-Type: text/html; charset=utf-8');

// Detectar sessão de usuário
$isLogged = !empty($_SESSION['user']);
$userAvatar = $isLogged && !empty($_SESSION['user']['avatar']) ? $_SESSION['user']['avatar'] : 'img/avatar.webp';
$userName = $isLogged && !empty($_SESSION['user']['name']) ? $_SESSION['user']['name'] : 'Visitante';
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>NUVVI | Beleza leve e natural</title>

    <link rel="stylesheet" href="index.css" />
    <link rel="icon" href="img/icon.png" type="image/png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
</head>

<body data-username="<?= htmlspecialchars($userName); ?>" data-avatar="<?= htmlspecialchars($userAvatar); ?>">

    <!-- HEADER -->
    <header class="site-header">

        <button class="menu-icon" id="btn-menu" aria-label="Abrir menu" aria-expanded="false">
            <span></span><span></span><span></span>
        </button>

        <div class="top-bar">
            <h1 class="logo"><a href="index.php">NUVVI</a></h1>
        </div>
    </header>

    <!-- BARRA DE PESQUISA FIXA -->
    <div class="search-bar" id="search-bar">
        <form action="produtos.php" method="GET">
            <input type="text" name="search" placeholder="Buscar produtos..." required>
            <button type="submit">
                <i class="fas fa-search"></i>
            </button>
        </form>
    </div>

    <!-- MENU LATERAL -->
    <nav class="sidebar" id="sidebar" aria-hidden="true">
        <div class="sidebar-header">
            <button class="close-menu" id="close-menu">✕</button>

            <img src="<?= htmlspecialchars($userAvatar); ?>" class="avatar" />
            <p class="username"><?= htmlspecialchars($userName); ?></p>

            <?php if ($isLogged): ?>
            <span class="user-status">Online</span>
            <?php else: ?>
            <span class="user-status guest">Visitante</span>
            <?php endif; ?>
        </div>

        <div class="menu">
            <a href="index.php" class="active"><i class="fas fa-home"></i>Início</a>
            <a href="produtos.php"><i class="fas fa-box-open"></i>Produtos</a>

            <?php if ($isLogged): ?>
            <a href="carrinho.php"><i class="fas fa-shopping-cart"></i>Carrinho</a>
            <?php endif; ?>

            <div class="menu-divider"></div>

            <?php if (!$isLogged): ?>
            <a href="login.php"><i class="fas fa-sign-in-alt"></i>Login</a>
            <a href="registrar.php"><i class="fas fa-user-plus"></i>Cadastro</a>
            <?php else: ?>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Sair</a>
            <?php endif; ?>
        </div>
    </nav>

    <div class="overlay" id="overlay"></div>

    <!-- HERO -->
    <main>
        <section class="hero-wrapper">
            <div class="hero">
                <div class="hero-text">
                    <h2>Beleza leve e natural</h2>
                    <p>Produtos naturais para cuidar de você com leveza e amor</p>

                    <div class="hero-buttons">
                        <a href="produtos.php" class="btn-primary">🎉 50% OFF na primeira compra</a>
                        <a href="produtos.php" class="btn-secondary">Começar a comprar</a>
                    </div>
                </div>

                <div class="hero-image">
                    <img src="img/imgbelezamulher.jpg" alt="Produto destaque">
                </div>
            </div>
        </section>

        <!-- CATEGORIAS REDONDAS -->
        <h2 class="titulo-categorias">Categorias</h2>

        <section class="categorias">
            <a href="produtos.php?categoria=creme-dental" class="categoria-item">
                <img src="img/categorias/cremedental.jpg">
                <p>Creme Dental</p>
            </a>

            <a href="produtos.php?categoria=desodorante" class="categoria-item">
                <img src="img/categorias/desodorante.jpg">
                <p>Desodorante</p>
            </a>

            <a href="produtos.php?categoria=protetor-solar" class="categoria-item">
                <img src="img/categorias/protetorsolar.webp">
                <p>Protetor Solar</p>
            </a>

            <a href="produtos.php?categoria=cabelo" class="categoria-item">
                <img src="img/categorias/cabelo.png">
                <p>Cabelo</p>
            </a>

            <a href="produtos.php?categoria=lip-balm" class="categoria-item">
                <img src="img/categorias/lipbalm.png">
                <p>Lip Balm</p>
            </a>

            <a href="produtos.php?categoria=presentes" class="categoria-item">
                <img src="img/categorias/presentes.png">
                <p>Presentes</p>
            </a>
        </section>

        <!-- DESTAQUES -->
        <div class="destaque-container">
            <h2>Produtos em Destaque</h2>

            <div class="destaques">

                <div class="destaque-card">
                    <img src="img/shampoo.png" alt="">
                    <h3>Shampoo Natural</h3>
                    <p>R$ 39,90</p>
                </div>

                <div class="destaque-card">
                    <img src="img/cremehidratante.png" alt="">
                    <h3>Creme Hidratante</h3>
                    <p>R$ 29,90</p>
                </div>

                <div class="destaque-card">
                    <img src="img/serumc.png" alt="">
                    <h3>Vitamin C Serum</h3>
                    <p>R$ 59,90</p>
                </div>

            </div>

            <a href="produtos.php" class="ver-mais">
                Ver mais produtos <i class="fas fa-arrow-right"></i>
            </a>
        </div>

    </main>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-container">

            <div class="footer-col">
                <h3 class="footer-title">NUVVI</h3>
                <p class="footer-desc">Beleza natural, leve e consciente.</p>
            </div>

            <div class="footer-col">
                <h4>Links úteis</h4>
                <ul>
                    <li><a href="index.php">Início</a></li>
                    <li><a href="produtos.php">Produtos</a></li>
                    <li><a href="contato.php">Contato</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Contato</h4>
                <p>Email: atendimento@nuvvi.com.br</p>
                <p>WhatsApp: (11) 99999-9999</p>
            </div>

        </div>

        <div class="footer-copy">
            © 2025 NUVVI — Todos os direitos reservados.
        </div>
    </footer>

    <!-- JS MENU -->
    <script>
    (function() {
        const btnMenu = document.getElementById('btn-menu');
        const closeMenu = document.getElementById('close-menu');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        const searchToggle = document.getElementById('search-toggle');
        const searchBar = document.getElementById('search-bar');

        function toggleMenu(open) {
            sidebar.classList.toggle('open', open);
            overlay.classList.toggle('active', open);
            btnMenu.classList.toggle('active', open);
            document.body.style.overflow = open ? 'hidden' : '';
        }

        btnMenu.onclick = () => toggleMenu(true);
        closeMenu.onclick = () => toggleMenu(false);
        overlay.onclick = () => toggleMenu(false);

        // Toggle search bar visibility
        searchToggle.onclick = () => {
            searchBar.classList.toggle('active');
        };
    })();
    </script>

</body>

</html>