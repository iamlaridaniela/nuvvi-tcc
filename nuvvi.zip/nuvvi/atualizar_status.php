<?php
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$id = $_POST['id'] ?? null;
$user_id = $_SESSION['user_id'];

if ($id) {
    // Verifica a tarefa e o status atual
    $stmt = $conn->prepare("SELECT status FROM tarefas WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $tarefa = $res->fetch_assoc();

        $novo_status = match ($tarefa['status']) {
            'pendente' => 'em_andamento',
            'em_andamento' => 'concluida',
            default => 'concluida'
        };

        $update = $conn->prepare("UPDATE tarefas SET status = ? WHERE id = ? AND user_id = ?");
        $update->bind_param("sii", $novo_status, $id, $user_id);
        $update->execute();
    }
}

header("Location: tarefas.php");
exit;
