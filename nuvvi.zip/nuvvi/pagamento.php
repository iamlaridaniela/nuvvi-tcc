<?php
session_start();

// Detectar sessão de usuário
$isLogged = !empty($_SESSION['user']);
$userAvatar = $isLogged && !empty($_SESSION['user']['avatar']) ? $_SESSION['user']['avatar'] : 'img/avatar.webp';
$userName = $isLogged && !empty($_SESSION['user']['name']) ? $_SESSION['user']['name'] : 'Visitante';

// Simula o total do carrinho
$total = 0;
if (!empty($_SESSION['carrinho'])) {
    foreach ($_SESSION['carrinho'] as $item) {
        $total += $item['preco'] * $item['quantidade'];
    }
} else {
    $total = 89.90; // valor padrão
}

$pagamento_realizado = false;
$metodo = $_POST['metodo'] ?? 'cartao';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pagamento_realizado = true;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Pagamento | NUVVI</title>

    <link rel="icon" href="img/icon.png" type="image/png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

    <style>
    /* ========================================================== 
       FONT-FACE
    ========================================================== */
    @font-face {
        font-family: 'Playfair Display SC';
        src: url('./font/PlayfairDisplaySC-Regular.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
    }

    /* ==========================================================
       RESET E BASE
    ========================================================== */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: "Poppins", sans-serif;
        background-color: #f7f7f7;
        color: #333;
        overflow-x: hidden;
    }

    /* ==========================================================
       HEADER SUPERIOR
    ========================================================== */
    .site-header {
        background: #2d572c;
        color: white;
        padding: 1rem;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    /* ==========================================================
       MENU HAMBÚRGUER
    ========================================================== */
    .menu-icon {
        width: 45px;
        height: 45px;
        background: transparent;
        border: none;
        cursor: pointer;
        padding: 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 6px;
        margin-right: 1rem;
        transition: all 0.3s ease;
        position: relative;
    }

    .menu-icon span {
        display: block;
        width: 28px;
        height: 3px;
        background: white;
        border-radius: 3px;
        transition: all 0.3s ease;
        transform-origin: center;
    }

    .menu-icon.active span:nth-child(1) {
        transform: translateY(9px) rotate(45deg);
    }

    .menu-icon.active span:nth-child(2) {
        opacity: 0;
        transform: translateX(-20px);
    }

    .menu-icon.active span:nth-child(3) {
        transform: translateY(-9px) rotate(-45deg);
    }

    .top-bar {
        flex: 1;
        display: flex;
        justify-content: center;
    }

    .logo a {
        color: #fff;
        font-family: 'Playfair Display SC';
        text-decoration: none !important;
        letter-spacing: 3px;
        font-weight: 700;
        font-size: 1.3rem;
    }

    /* ==========================================================
       SIDEBAR
    ========================================================== */
    .sidebar {
        position: fixed;
        left: -250px;
        top: 0;
        height: 100vh;
        width: 250px;
        background: #fff;
        border-right: 1px solid #ccc;
        transition: left 0.4s ease;
        overflow-x: hidden;
        overflow-y: auto;
        z-index: 1001;
        box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.open {
        left: 0;
    }

    .sidebar-header {
        text-align: center;
        padding: 1.5rem 1rem;
        border-bottom: 1px solid #e0e0e0;
        background: #2d572c;
        position: relative;
    }

    .avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid white;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        transition: transform 0.3s ease;
        margin-bottom: 0.8rem;
    }

    .avatar:hover {
        transform: scale(1.05);
    }

    .username {
        font-weight: 600;
        font-size: 1.1rem;
        color: white;
        margin: 0.5rem 0 0.3rem 0;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    }

    .user-status {
        display: inline-block;
        font-size: 0.8rem;
        color: white;
        background: rgba(255, 255, 255, 0.2);
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-weight: 500;
        backdrop-filter: blur(10px);
    }

    .user-status.guest {
        background: rgba(255, 255, 255, 0.15);
    }

    .close-menu {
        position: absolute;
        top: 1rem;
        right: 1rem;
        width: 40px;
        height: 40px;
        background: rgba(255, 255, 255, 0.3);
        border: 2px solid rgba(255, 255, 255, 0.5);
        border-radius: 50%;
        color: white;
        font-size: 1.5rem;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        line-height: 1;
    }

    .close-menu:hover {
        background: rgba(255, 255, 255, 0.5);
        transform: rotate(90deg);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    }

    /* ==========================================================
       MENU LATERAL
    ========================================================== */
    .menu {
        margin-top: 1rem;
        padding: 0 0.8rem;
        max-height: calc(100vh - 250px);
        overflow-y: auto;
    }

    .menu::-webkit-scrollbar {
        width: 6px;
    }

    .menu::-webkit-scrollbar-thumb {
        background: #2d572c;
    }

    .menu ul {
        list-style: none;
    }

    .menu ul li a {
        text-decoration: none;
        color: #333;
        font-weight: 600;
        font-size: 0.95rem;
        padding: 12px 14px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 12px;
        transition: 0.3s;
    }

    .menu ul li a:hover,
    .menu ul li a.active {
        background-color: #2d572c;
        color: #fff;
        transform: translateX(5px);
    }

    .menu-divider {
        height: 1px;
        background: #e0e0e0;
        margin: 0.8rem 0;
    }

    .menu-section {
        margin-top: 1.5rem;
    }

    .menu-section-title {
        font-size: 0.85rem;
        font-weight: 700;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 1px;
        padding: 0 14px;
        margin-bottom: 0.5rem;
    }

    .overlay {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 999;
    }

    .overlay.active {
        opacity: 1;
        visibility: visible;
    }

    /* ==========================================================
       CONTEÚDO PRINCIPAL - PAGAMENTO
    ========================================================== */
    .container {
        max-width: 700px;
        margin: 3rem auto;
        padding: 2.5rem;
        background: white;
        border-radius: 20px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
    }

    .page-title {
        font-size: 32px;
        font-weight: 700;
        color: #2d572c;
        text-align: center;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
    }

    .total-box {
        background: linear-gradient(135deg, #2d572c 0%, #3d6d3c 100%);
        color: white;
        padding: 20px;
        border-radius: 16px;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 4px 12px rgba(45, 87, 44, 0.2);
    }

    .total-box p {
        font-size: 0.95rem;
        margin-bottom: 8px;
        opacity: 0.9;
    }

    .total-box .valor {
        font-size: 2.2rem;
        font-weight: 700;
        margin-top: 5px;
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    label {
        font-weight: 600;
        color: #333;
        font-size: 0.95rem;
        margin-bottom: 5px;
        display: block;
    }

    input,
    select {
        padding: 14px 16px;
        border: 2px solid #e0e0e0;
        border-radius: 12px;
        font-size: 1rem;
        font-family: 'Poppins', sans-serif;
        transition: 0.3s ease;
        width: 100%;
    }

    input:focus,
    select:focus {
        outline: none;
        border-color: #2d572c;
        box-shadow: 0 0 0 3px rgba(45, 87, 44, 0.1);
    }

    select {
        cursor: pointer;
        background: white;
    }

    button {
        background: #2d572c;
        color: white;
        border: none;
        border-radius: 30px;
        padding: 16px 28px;
        cursor: pointer;
        font-size: 1.1rem;
        font-weight: 600;
        margin-top: 20px;
        transition: 0.3s ease;
        font-family: 'Poppins', sans-serif;
    }

    button:hover {
        background: #3d6d3c;
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(45, 87, 44, 0.3);
    }

    .metodo-section {
        display: none;
        animation: fadeIn 0.3s ease;
    }

    .metodo-section.active {
        display: block;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .pix-box {
        background: #f9fdf9;
        padding: 25px;
        border-radius: 16px;
        border: 2px dashed #2d572c;
        text-align: center;
    }

    .pix-box img {
        width: 220px;
        height: 220px;
        margin: 15px 0;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .pix-box .chave {
        background: white;
        padding: 12px 20px;
        border-radius: 10px;
        display: inline-block;
        margin-top: 15px;
        font-weight: 600;
        color: #2d572c;
        border: 2px solid #2d572c;
    }

    .boleto-box {
        background: #fff9e6;
        padding: 25px;
        border-radius: 16px;
        border: 2px solid #f0c84b;
        text-align: center;
    }

    .boleto-box i {
        font-size: 3rem;
        color: #f0c84b;
        margin-bottom: 15px;
    }

    .boleto-box .vencimento {
        font-size: 1.2rem;
        font-weight: 600;
        color: #333;
        margin-top: 10px;
    }

    /* Sucesso */
    .sucesso-container {
        text-align: center;
        padding: 2rem 0;
    }

    .sucesso-icon {
        width: 100px;
        height: 100px;
        background: #2d572c;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem auto;
        animation: scaleIn 0.5s ease;
    }

    .sucesso-icon i {
        font-size: 3rem;
        color: white;
    }

    @keyframes scaleIn {
        from {
            transform: scale(0);
            opacity: 0;
        }

        to {
            transform: scale(1);
            opacity: 1;
        }
    }

    .sucesso-title {
        font-size: 2rem;
        font-weight: 700;
        color: #2d572c;
        margin-bottom: 1rem;
    }

    .sucesso-message {
        font-size: 1.1rem;
        color: #666;
        margin-bottom: 2rem;
    }

    .input-row {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 15px;
    }

    /* ==========================================================
       FOOTER
    ========================================================== */
    .site-footer {
        background: #2d572c;
        color: #ffffff;
        padding: 60px 20px 20px 20px;
        margin-top: 60px;
    }

    .footer-container {
        max-width: 1250px;
        margin: auto;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 40px;
    }

    .footer-col {
        flex: 1 1 250px;
    }

    .footer-title {
        font-family: 'Playfair Display SC';
        font-size: 28px;
        margin-bottom: 10px;
        letter-spacing: 2px;
    }

    .footer-desc {
        color: #d9e6d9;
        font-size: 15px;
        line-height: 1.5;
        margin-top: 8px;
    }

    .footer-col h4 {
        font-size: 18px;
        margin-bottom: 15px;
        font-weight: 600;
        color: #e9f5ea;
    }

    .footer-col ul {
        list-style: none;
    }

    .footer-col ul li {
        margin-bottom: 10px;
    }

    .footer-col ul li a {
        color: #d9e6d9;
        text-decoration: none;
        transition: 0.2s ease;
    }

    .footer-col ul li a:hover {
        color: #ffffff;
        padding-left: 4px;
    }

    .footer-copy {
        text-align: center;
        font-size: 14px;
        margin-top: 35px;
        color: #d3e4d3;
    }

    /* ==========================================================
       RESPONSIVIDADE
    ========================================================== */
    @media (max-width: 700px) {
        .footer-container {
            text-align: center;
        }

        .footer-col {
            flex: 1 1 100%;
        }

        .container {
            margin: 2rem 1rem;
            padding: 1.5rem;
        }

        .input-row {
            grid-template-columns: 1fr;
        }

        .page-title {
            font-size: 24px;
        }

        .total-box .valor {
            font-size: 1.8rem;
        }
    }
    </style>

    <script>
    function mostrarMetodo() {
        const metodo = document.getElementById("metodo").value;
        document.querySelectorAll(".metodo-section").forEach(sec => sec.classList.remove("active"));
        document.getElementById("sec-" + metodo).classList.add("active");
    }
    </script>
</head>

<body>

    <!-- HEADER -->
    <header class="site-header">
        <button class="menu-icon" id="btn-menu" aria-label="Abrir menu" aria-expanded="false">
            <span></span><span></span><span></span>
        </button>

        <div class="top-bar">
            <h1 class="logo"><a href="index.php">NUVVI</a></h1>
        </div>
    </header>

   <!-- MENU LATERAL SIMPLIFICADO -->
<nav class="sidebar" id="sidebar" aria-hidden="true">
    <div class="sidebar-header">
        <button class="close-menu" id="close-menu">✕</button>

        <img src="<?= htmlspecialchars($userAvatar); ?>" class="avatar" />
        <p class="username"><?= htmlspecialchars($userName); ?></p>

        <span class="user-status <?= $isLogged ? '' : 'guest' ?>">
            <?= $isLogged ? 'Online' : 'Visitante' ?>
        </span>
    </div>

    <div class="menu">
        <ul>
            <li><a href="index.php"><i class="fas fa-home"></i> Início</a></li>
            <li><a href="produtos.php"><i class="fas fa-box-open"></i> Produtos</a></li>
            <?php if ($isLogged): ?>
            <li><a href="carrinho.php"><i class="fas fa-shopping-cart"></i> Carrinho</a></li>
            <?php endif; ?>

            <li class="menu-divider"></li>
            <?php if (!$isLogged): ?>
            <li><a href="login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
            <li><a href="registrar.php"><i class="fas fa-user-plus"></i> Cadastro</a></li>
            <?php else: ?>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            <?php endif; ?>
        </ul>

        <!-- Menu de Pagamento Rápido -->
        <div class="menu-section">
            <h3 class="menu-section-title">Pagamento</h3>
            <ul>
                <li><a href="#sec-cartao"><i class="fas fa-credit-card"></i> Cartão</a></li>
                <li><a href="#sec-pix"><i class="fas fa-qrcode"></i> PIX</a></li>
                <li><a href="#sec-boleto"><i class="fas fa-barcode"></i> Boleto</a></li>
            </ul>
        </div>
    </div>
</nav>


    <div class="overlay" id="overlay"></div>

    <!-- CONTEÚDO PRINCIPAL -->
    <main>
        <div class="container">
            <?php if ($pagamento_realizado): ?>
            <!-- SUCESSO -->
            <div class="sucesso-container">
                <div class="sucesso-icon">
                    <i class="fas fa-check"></i>
                </div>
                <h2 class="sucesso-title">Pagamento realizado com sucesso!</h2>
                <p class="sucesso-message">Obrigado por comprar na NUVVI 🌿</p>

                <div class="total-box">
                    <p>Valor pago</p>
                    <div class="valor">R$ <?= number_format($total, 2, ',', '.') ?></div>
                </div>

                <a href="index.php"><button><i class="fas fa-home"></i> Voltar para a Página Inicial</button></a>
            </div>

            <?php else: ?>
            <!-- FORMULÁRIO DE PAGAMENTO -->
            <h2 class="page-title">
                <i class="fas fa-credit-card"></i> Pagamento
            </h2>

            <div class="total-box">
                <p>Total a pagar</p>
                <div class="valor">R$ <?= number_format($total, 2, ',', '.') ?></div>
            </div>

            <form method="POST" oninput="mostrarMetodo()">
                <div>
                    <label for="metodo"><i class="fas fa-wallet"></i> Método de Pagamento</label>
                    <select id="metodo" name="metodo" required>
                        <option value="cartao" selected>💳 Cartão de Crédito</option>
                        <option value="pix">🔵 Pix</option>
                        <option value="boleto">📄 Boleto Bancário</option>
                    </select>
                </div>

                <!-- Cartão -->
                <div id="sec-cartao" class="metodo-section active">
                    <div>
                        <label for="nome">Nome no Cartão</label>
                        <input type="text" id="nome" name="nome" placeholder="Como está escrito no cartão">
                    </div>

                    <div>
                        <label for="numero">Número do Cartão</label>
                        <input type="text" id="numero" name="numero" maxlength="16" placeholder="0000 0000 0000 0000">
                    </div>

                    <div class="input-row">
                        <div>
                            <label for="validade">Validade</label>
                            <input type="text" id="validade" name="validade" maxlength="5" placeholder="MM/AA">
                        </div>

                        <div>
                            <label for="cvv">CVV</label>
                            <input type="text" id="cvv" name="cvv" maxlength="3" placeholder="000">
                        </div>
                    </div>
                </div>

                <!-- PIX -->
                <div id="sec-pix" class="metodo-section">
                    <div class="pix-box">
                        <p style="font-size: 1.1rem; font-weight: 600; color: #2d572c;">Use o QR Code abaixo para pagar
                            via PIX:</p>
                        <img src="img/qr code.jpg" alt="QR Code PIX">
                        <div class="chave">
                            <i class="fas fa-key"></i> nuvvi@pagamentos.com
                        </div>
                        <p style="margin-top: 15px; color: #666; font-size: 0.9rem;">
                            Escaneie o QR Code ou use a chave PIX acima
                        </p>
                    </div>
                </div>

                <!-- Boleto -->
                <div id="sec-boleto" class="metodo-section">
                    <div class="boleto-box">
                        <i class="fas fa-barcode"></i>
                        <p style="font-size: 1.1rem; margin-bottom: 10px;">Um boleto será gerado após confirmar o
                            pagamento.</p>
                        <div class="vencimento">
                            <i class="fas fa-calendar-alt"></i> Vencimento: <?= date('d/m/Y', strtotime('+3 days')) ?>
                        </div>
                    </div>
                </div>

                <button type="submit">
                    <i class="fas fa-check-circle"></i> Confirmar Pagamento
                </button>
            </form>
            <?php endif; ?>
        </div>
    </main>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-container">

            <div class="footer-col">
                <h3 class="footer-title">NUVVI</h3>
                <p class="footer-desc">Beleza natural, leve e consciente.</p>
            </div>

            <div class="footer-col">
                <h4>Links úteis</h4>
                <ul>
                    <li><a href="index.php">Início</a></li>
                    <li><a href="produtos.php">Produtos</a></li>
                    <li><a href="contato.php">Contato</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Contato</h4>
                <p>Email: atendimento@nuvvi.com.br</p>
                <p>WhatsApp: (11) 99999-9999</p>
            </div>

        </div>

        <div class="footer-copy">
            © 2025 NUVVI — Todos os direitos reservados.
        </div>
    </footer>

    <!-- JS MENU -->
    <script>
    (function() {
        const btnMenu = document.getElementById('btn-menu');
        const closeMenu = document.getElementById('close-menu');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');

        function toggleMenu(open) {
            sidebar.classList.toggle('open', open);
            overlay.classList.toggle('active', open);
            btnMenu.classList.toggle('active', open);
            document.body.style.overflow = open ? 'hidden' : '';
        }

        btnMenu.onclick = () => toggleMenu(true);
        closeMenu.onclick = () => toggleMenu(false);
        overlay.onclick = () => toggleMenu(false);
    })();
    </script>

</body>

</html>