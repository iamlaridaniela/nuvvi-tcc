<?php
session_start();
require_once 'db.php';

// Detectar sessão de usuário
$isLogged = !empty($_SESSION['user']);
$userAvatar = $isLogged && !empty($_SESSION['user']['avatar']) ? $_SESSION['user']['avatar'] : 'img/avatar.webp';
$userName = $isLogged && !empty($_SESSION['user']['name']) ? $_SESSION['user']['name'] : 'Visitante';

// 🔍 Buscar categorias
$sql_categorias = "SELECT * FROM categorias ORDER BY nome ASC";
$result_categorias = $conn->query($sql_categorias);

// 🔍 Buscar produtos agrupados por categoria
$categoria_selecionada = isset($_GET['categoria']) ? $_GET['categoria'] : '';

if (!empty($categoria_selecionada)) {
    // Buscar produtos de uma categoria específica (usando ID da categoria)
    $sql_produtos = "SELECT p.*, c.nome AS categoria_nome
                     FROM produtos p 
                     LEFT JOIN categorias c ON p.categoria_id = c.id
                     WHERE c.id = ?
                     ORDER BY p.nome ASC";
    $stmt = $conn->prepare($sql_produtos);
    $stmt->bind_param("i", $categoria_selecionada);
    $stmt->execute();
    $result_produtos = $stmt->get_result();
    
    // Agrupar por categoria (será apenas uma)
    $produtos_por_categoria = [];
    while ($p = $result_produtos->fetch_assoc()) {
        $cat = $p['categoria_nome'] ?? 'Geral';
        if (!isset($produtos_por_categoria[$cat])) {
            $produtos_por_categoria[$cat] = [];
        }
        $produtos_por_categoria[$cat][] = $p;
    }
} else {
    // Buscar todos os produtos
    $sql_produtos = "SELECT p.*, c.nome AS categoria_nome
                     FROM produtos p 
                     LEFT JOIN categorias c ON p.categoria_id = c.id
                     ORDER BY c.nome ASC, p.nome ASC";
    $result_produtos = $conn->query($sql_produtos);
    
    // Agrupar produtos por categoria
    $produtos_por_categoria = [];
    while ($p = $result_produtos->fetch_assoc()) {
        $cat = $p['categoria_nome'] ?? 'Geral';
        if (!isset($produtos_por_categoria[$cat])) {
            $produtos_por_categoria[$cat] = [];
        }
        $produtos_por_categoria[$cat][] = $p;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Produtos | NUVVI</title>

    <link rel="icon" href="img/icon.png" type="image/png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

    <style>
    /* ========================================================== 
       FONT-FACE
    ========================================================== */
    @font-face {
        font-family: 'Playfair Display SC';
        src: url('./font/PlayfairDisplaySC-Regular.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
    }

    /* ==========================================================
       RESET E BASE
    ========================================================== */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: "Poppins", sans-serif;
        background-color: #f7f7f7;
        color: #333;
        overflow-x: hidden;
    }

    /* ==========================================================
       HEADER SUPERIOR
    ========================================================== */
    .site-header {
        background: #2d572c;
        color: white;
        padding: 1rem;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    /* ==========================================================
       MENU HAMBÚRGUER
    ========================================================== */
    .menu-icon {
        width: 45px;
        height: 45px;
        background: transparent;
        border: none;
        cursor: pointer;
        padding: 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 6px;
        margin-right: 1rem;
        transition: all 0.3s ease;
        position: relative;
    }

    .menu-icon span {
        display: block;
        width: 28px;
        height: 3px;
        background: white;
        border-radius: 3px;
        transition: all 0.3s ease;
        transform-origin: center;
    }

    .menu-icon.active span:nth-child(1) {
        transform: translateY(9px) rotate(45deg);
    }

    .menu-icon.active span:nth-child(2) {
        opacity: 0;
        transform: translateX(-20px);
    }

    .menu-icon.active span:nth-child(3) {
        transform: translateY(-9px) rotate(-45deg);
    }

    .top-bar {
        flex: 1;
        display: flex;
        justify-content: center;
    }

    .logo a {
        color: #fff;
        font-family: 'Playfair Display SC';
        text-decoration: none !important;
        letter-spacing: 3px;
        font-weight: 700;
        font-size: 1.3rem;
    }

    /* ==========================================================
       OVERLAY
    ========================================================== */
    .overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 1000;
    }

    .overlay.active {
        opacity: 1;
        visibility: visible;
    }

    /* ==========================================================
       SIDEBAR
    ========================================================== */
    .sidebar {
        position: fixed;
        left: -250px;
        top: 0;
        height: 100vh;
        width: 250px;
        background: #fff;
        border-right: 1px solid #ccc;
        transition: left 0.4s ease;
        overflow-x: hidden;
        overflow-y: auto;
        z-index: 1001;
        box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.open {
        left: 0;
    }

    .sidebar-header {
        text-align: center;
        padding: 1.5rem 1rem;
        border-bottom: 1px solid #e0e0e0;
        background: #2d572c;
        position: relative;
    }

    .avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid white;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        transition: transform 0.3s ease;
        margin-bottom: 0.8rem;
    }

    .avatar:hover {
        transform: scale(1.05);
    }

    .username {
        font-weight: 600;
        font-size: 1.1rem;
        color: white;
        margin: 0.5rem 0 0.3rem 0;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    }

    .user-status {
        display: inline-block;
        font-size: 0.8rem;
        color: white;
        background: rgba(255, 255, 255, 0.2);
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-weight: 500;
        backdrop-filter: blur(10px);
    }

    .user-status.guest {
        background: rgba(255, 255, 255, 0.15);
    }

    .close-menu {
        position: absolute;
        top: 1rem;
        right: 1rem;
        width: 40px;
        height: 40px;
        background: rgba(255, 255, 255, 0.3);
        border: 2px solid rgba(255, 255, 255, 0.5);
        border-radius: 50%;
        color: white;
        font-size: 1.5rem;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        line-height: 1;
    }

    .close-menu:hover {
        background: rgba(255, 255, 255, 0.5);
        transform: rotate(90deg);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    }

    /* ==========================================================
       MENU LATERAL (SEM <li>)
    ========================================================== */
    .menu {
        margin-top: 1rem;
        padding: 0 0.8rem 1rem 0.8rem;
        max-height: calc(100vh - 250px);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 0.3rem;
    }

    .menu::-webkit-scrollbar {
        width: 6px;
    }

    .menu::-webkit-scrollbar-thumb {
        background: #2d572c;
        border-radius: 3px;
    }

    .menu-section-title {
        font-size: 0.85rem;
        font-weight: 700;
        color: #2d572c;
        text-transform: uppercase;
        letter-spacing: 1px;
        padding: 1rem 14px 0.5rem 14px;
        margin-top: 0.5rem;
    }

    /* Links do menu */
    .menu a {
        text-decoration: none;
        color: #333;
        font-weight: 600;
        font-size: 0.95rem;
        padding: 12px 14px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 12px;
        transition: all 0.3s ease;
    }

    .menu a i {
        font-size: 1.1rem;
        width: 20px;
        text-align: center;
    }

    .menu a:hover,
    .menu a.active {
        background-color: #2d572c;
        color: #fff;
        transform: translateX(5px);
    }

    /* ==========================================================
       BARRA DE PESQUISA
    ========================================================== */
    .search-bar {
        width: 100%;
        display: flex;
        justify-content: center;
        background: #f1f1ee;
        padding: 18px 0;
        position: sticky;
        top: 60px;
        z-index: 999;
        transition: all 0.3s ease;
    }

    .search-bar form {
        width: 100%;
        max-width: 600px;
        display: flex;
        background: #ffffff;
        border-radius: 35px;
        padding: 6px 14px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.07);
        border: 1px solid #e5e5e2;
    }

    .search-bar input {
        flex: 1;
        border: none;
        outline: none;
        padding: 12px 18px;
        font-size: 15px;
        background: transparent;
        color: #333;
    }

    .search-bar button {
        background: #7da77c;
        border: none;
        color: white;
        width: 46px;
        height: 46px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: 0.2s ease;
    }

    .search-bar button:hover {
        filter: brightness(1.1);
    }

    /* ==========================================================
       CONTEÚDO PRINCIPAL - PRODUTOS
    ========================================================== */
    .container {
        max-width: 1250px;
        margin: 2rem auto;
        padding: 0 20px;
    }

    .page-title {
        text-align: center;
        font-size: 32px;
        font-weight: 700;
        color: #2d572c;
        margin-bottom: 1rem;
    }

    .categoria-section {
        margin-bottom: 3rem;
    }

    .categoria-titulo {
        font-size: 24px;
        font-weight: 700;
        color: #2d572c;
        margin-bottom: 1.5rem;
        padding-bottom: 0.5rem;
        border-bottom: 3px solid #2d572c;
        display: inline-block;
    }

    .produtos-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 25px;
        margin-top: 1.5rem;
    }

    .produto-card {
        background: #fff;
        border-radius: 18px;
        padding: 18px;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.06);
        transition: 0.25s ease;
        cursor: pointer;
        text-align: center;
    }

    .produto-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.12);
    }

    .produto-card img {
        width: 100%;
        height: 220px;
        border-radius: 14px;
        object-fit: cover;
        margin-bottom: 15px;
    }

    .produto-info h3 {
        font-size: 1.1rem;
        color: #333;
        margin: 0.5rem 0;
        font-weight: 600;
    }

    .produto-info .categoria {
        color: #888;
        font-size: 0.85rem;
        margin-bottom: 0.5rem;
    }

    .produto-info .preco {
        color: #2d572c;
        font-weight: 700;
        font-size: 1.3rem;
        margin: 0.8rem 0;
    }

    .produto-info button {
        background: #2d572c;
        color: #fff;
        border: none;
        border-radius: 25px;
        padding: 10px 24px;
        margin-top: 10px;
        cursor: pointer;
        font-weight: 600;
        font-size: 0.95rem;
        transition: 0.2s ease;
    }

    .produto-info button:hover {
        background: #3d6d3c;
        transform: scale(1.05);
    }

    .empty-message {
        text-align: center;
        padding: 3rem;
        color: #666;
        font-size: 1.1rem;
    }

    /* ==========================================================
       FOOTER
    ========================================================== */
    .site-footer {
        background: #2d572c;
        color: #ffffff;
        padding: 60px 20px 20px 20px;
        margin-top: 60px;
    }

    .footer-container {
        max-width: 1250px;
        margin: auto;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 40px;
    }

    .footer-col {
        flex: 1 1 250px;
    }

    .footer-title {
        font-family: 'Playfair Display SC';
        font-size: 28px;
        margin-bottom: 10px;
        letter-spacing: 2px;
    }

    .footer-desc {
        color: #d9e6d9;
        font-size: 15px;
        line-height: 1.5;
        margin-top: 8px;
    }

    .footer-col h4 {
        font-size: 18px;
        margin-bottom: 15px;
        font-weight: 600;
        color: #e9f5ea;
    }

    .footer-col ul {
        list-style: none;
    }

    .footer-col ul li {
        margin-bottom: 10px;
    }

    .footer-col ul li a {
        color: #d9e6d9;
        text-decoration: none;
        transition: 0.2s ease;
    }

    .footer-col ul li a:hover {
        color: #ffffff;
        padding-left: 4px;
    }

    .footer-copy {
        text-align: center;
        font-size: 14px;
        margin-top: 35px;
        color: #d3e4d3;
    }

    /* ==========================================================
       RESPONSIVIDADE
    ========================================================== */
    @media (max-width: 700px) {
        .footer-container {
            text-align: center;
        }

        .footer-col {
            flex: 1 1 100%;
        }
    }

    @media (max-width: 600px) {
        .search-bar form {
            max-width: 90%;
        }

        .page-title {
            font-size: 24px;
        }

        .produtos-grid {
            grid-template-columns: 1fr;
        }
    }
    </style>
</head>

<body>

    <!-- HEADER -->
    <header class="site-header">
        <button class="menu-icon" id="btn-menu" aria-label="Abrir menu" aria-expanded="false">
            <span></span><span></span><span></span>
        </button>

        <div class="top-bar">
            <h1 class="logo"><a href="index.php">NUVVI</a></h1>
        </div>
    </header>

    <!-- BARRA DE PESQUISA FIXA -->
    <div class="search-bar" id="search-bar">
        <form action="produtos.php" method="GET">
            <input type="text" name="search" placeholder="Buscar produtos..." required>
            <button type="submit">
                <i class="fas fa-search"></i>
            </button>
        </form>
    </div>

    <!-- MENU LATERAL -->
    <nav class="sidebar" id="sidebar" aria-hidden="true">
        <div class="sidebar-header">
            <button class="close-menu" id="close-menu">✕</button>

            <img src="<?= htmlspecialchars($userAvatar); ?>" class="avatar" />
            <p class="username"><?= htmlspecialchars($userName); ?></p>

            <?php if ($isLogged): ?>
            <span class="user-status">Online</span>
            <?php else: ?>
            <span class="user-status guest">Visitante</span>
            <?php endif; ?>
        </div>

   <div class="menu">
    <!-- INÍCIO -->
    <a href="index.php" class="">
        <i class="fas fa-home"></i>Início
    </a>

    <h3 class="menu-section-title">Categorias</h3>

    <!-- Todos os Produtos -->
    <a href="produtos.php" class="<?= empty($categoria_selecionada) ? 'active' : '' ?>">
        <i class="fas fa-th"></i>Todos os Produtos
    </a>

    <?php
    // IDs das categorias que devem aparecer no menu
    $categorias_menu = [16, 17];

    // Busca as categorias desejadas no banco
    $sql_cat_menu = "SELECT id, nome FROM categorias WHERE id IN (16, 17) ORDER BY nome ASC";
    $result_cat_menu = $conn->query($sql_cat_menu);

    if ($result_cat_menu && $result_cat_menu->num_rows > 0):
        while ($cat = $result_cat_menu->fetch_assoc()):
    ?>
        <a href="produtos.php?categoria=<?= $cat['id']; ?>"
           class="<?= $categoria_selecionada == $cat['id'] ? 'active' : '' ?>">
            <i class="fas fa-tag"></i><?= htmlspecialchars($cat['nome']); ?>
        </a>
    <?php
        endwhile;
    endif;
    ?>

    <!-- Carrinho -->
    <h3 class="menu-section-title">Compras</h3>

    <a href="carrinho.php">
        <i class="fas fa-shopping-cart"></i>Carrinho
    </a>

    <a href="pagamento.php">
        <i class="fas fa-credit-card"></i>Formas de Pagamento
    </a>

    <!-- SAIR (somente logado) -->
    <?php if ($isLogged): ?>
        <h3 class="menu-section-title">Conta</h3>
        <a href="logout.php" style="color:#c0392b; font-weight:700;">
            <i class="fas fa-sign-out-alt"></i>Sair
        </a>
    <?php endif; ?>
</div>

    </nav>

    <div class="overlay" id="overlay"></div>

    <!-- CONTEÚDO PRINCIPAL -->
    <main>
        <div class="container">
            <h2 class="page-title">Nossos Produtos</h2>

            <?php if (!empty($produtos_por_categoria)): ?>
                <?php foreach ($produtos_por_categoria as $categoria => $produtos): ?>
                <div class="categoria-section">
                    <h3 class="categoria-titulo"><?= htmlspecialchars($categoria) ?></h3>
                    
                    <div class="produtos-grid">
                        <?php foreach ($produtos as $p): ?>
                        <div class="produto-card">
                            <img src="img/<?= htmlspecialchars($p['imagem'] ?: 'placeholder.png') ?>"
                                alt="<?= htmlspecialchars($p['nome']) ?>">
                            <div class="produto-info">
                                <h3><?= htmlspecialchars($p['nome']) ?></h3>
                                <div class="preco">R$ <?= number_format($p['preco'], 2, ',', '.') ?></div>
                                <form method="POST" action="carrinho.php">
                                    <input type="hidden" name="produto_id" value="<?= $p['id'] ?>">
                                    <button type="submit"><i class="fas fa-shopping-cart"></i> Adicionar</button>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-message">
                    <i class="fas fa-box-open" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                    <p>Nenhum produto encontrado.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-container">

            <div class="footer-col">
                <h3 class="footer-title">NUVVI</h3>
                <p class="footer-desc">Beleza natural, leve e consciente.</p>
            </div>

            <div class="footer-col">
                <h4>Links úteis</h4>
                <ul>
                    <li><a href="index.php">Início</a></li>
                    <li><a href="produtos.php">Produtos</a></li>
                    <li><a href="contato.php">Contato</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Contato</h4>
                <p>Email: atendimento@nuvvi.com.br</p>
                <p>WhatsApp: (11) 99999-9999</p>
            </div>

        </div>

        <div class="footer-copy">
            © 2025 NUVVI — Todos os direitos reservados.
        </div>
    </footer>

    <!-- JS MENU -->
    <script>
    (function() {
        const btnMenu = document.getElementById('btn-menu');
        const closeMenu = document.getElementById('close-menu');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');

        function toggleMenu(open) {
            sidebar.classList.toggle('open', open);
            overlay.classList.toggle('active', open);
            btnMenu.classList.toggle('active', open);
            document.body.style.overflow = open ? 'hidden' : '';
        }

        btnMenu.onclick = () => toggleMenu(true);
        closeMenu.onclick = () => toggleMenu(false);
        overlay.onclick = () => toggleMenu(false);
    })();
    </script>

</body>

</html>