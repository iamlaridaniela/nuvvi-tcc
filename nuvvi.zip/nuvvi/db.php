<?php
$conn = new mysqli('localhost', 'root', '', 'nuvvi');
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}
?>
